LOGGER.error("Error ", ${EXCEPTION});
